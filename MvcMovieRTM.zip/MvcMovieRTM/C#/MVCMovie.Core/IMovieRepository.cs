﻿using System.Collections.Generic;

namespace MVCMovie.Core
{
    public interface IMovieRepository
    {
        IEnumerable<Movie> GetMovies();
        void Add(Movie m);
        void Edit(Movie m);
        void Remove(int id);
        void Dispose();
        Movie Find(int id);
    }
}