using System.Collections.Generic;
using Ocean.DbConfiguration;

namespace Ocean.Installation
{
    public interface IDatabaseCreationService
    {
        InstallationResult ValidateConnectionString(InstallModel model);
        IDatabaseProvider CreateDatabase(InstallModel model);
    }
}