namespace Ocean.Installation
{
    public interface IRestartApplication
    {
        void Restart();
    }
}