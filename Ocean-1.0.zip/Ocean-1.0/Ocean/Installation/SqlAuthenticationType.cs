namespace Ocean.Installation
{
    public enum SqlAuthenticationType
    {
        SQL,
        Windows
    }
}