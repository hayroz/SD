namespace Ocean.Installation
{
    public interface IInitializeDatabase
    {
        void Initialize(InstallModel model);
    }
}