namespace Ocean.Installation
{
    public interface IFileSystemAccessService
    {
        InstallationResult EnsureAccessToFileSystem();
        void EmptyAppData();
    }
}