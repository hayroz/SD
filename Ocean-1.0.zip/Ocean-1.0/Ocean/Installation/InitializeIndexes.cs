using Ocean.Website;

namespace Ocean.Installation
{
    public class InitializeIndexes : EndRequestTask<int>
    {
        public InitializeIndexes() : base(0)
        {
        }
    }
}