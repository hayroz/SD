using System;
using System.Collections.Generic;
using Ocean.Helpers;
using Ocean.Indexing.Management;
using Ocean.Search;
using Ocean.Services;
using Ocean.Website;
using Ninject;

namespace Ocean.Installation
{
    public class InitializeIndexesExecutor : ExecuteEndRequestBase<InitializeIndexes, int>
    {
        private readonly IIndexService _indexService;
        private readonly IUniversalSearchIndexManager _universalSearchIndexManager;

        public InitializeIndexesExecutor(IIndexService indexService, IUniversalSearchIndexManager universalSearchIndexManager)
        {
            _indexService = indexService;
            _universalSearchIndexManager = universalSearchIndexManager;
        }

        public override void Execute(IEnumerable<int> data)
        {
            foreach (var indexManager in _indexService.GetAllIndexManagers())
            {
                indexManager.ReIndex();
            }
            _universalSearchIndexManager.ReindexAll();
        }
    }
}