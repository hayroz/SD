using Ocean.Batching.Entities;

namespace Ocean.Batching.Services
{
    public interface ISetRunStatus
    {
        void Complete(BatchRun batchRun);
        void Paused(BatchRun batchRun);
    }
}