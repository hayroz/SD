﻿using System.Linq;
using Ocean.Batching.Entities;

namespace Ocean.Batching.Services
{
    public interface ICreateBatchRun
    {
        BatchRun Create(Batch batch);
    }
}