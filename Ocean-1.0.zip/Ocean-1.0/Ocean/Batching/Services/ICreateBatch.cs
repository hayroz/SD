using System.Collections.Generic;
using Ocean.Batching.Entities;
using Ocean.Services.FileMigration;
using Newtonsoft.Json;

namespace Ocean.Batching.Services
{
    public interface ICreateBatch
    {
        BatchCreationResult Create(IEnumerable<BatchJob> jobs);
    }
}