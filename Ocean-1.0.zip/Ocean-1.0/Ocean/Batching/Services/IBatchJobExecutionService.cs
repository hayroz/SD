using System.Threading.Tasks;
using Ocean.Batching.Entities;

namespace Ocean.Batching.Services
{
    public interface IBatchJobExecutionService
    {
        Task<BatchJobExecutionResult> Execute(BatchJob batchJob);
    }
}