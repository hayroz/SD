using System.Diagnostics;
using System.Threading.Tasks;
using Ocean.Batching.Entities;

namespace Ocean.Batching.Services
{
    public interface IRunBatchRunResult
    {
        Task<BatchJobExecutionResult> Run(BatchRunResult runResult, Stopwatch stopWatch = null);
    }
}