﻿using Ocean.Batching.Entities;

namespace Ocean.Batching.Services
{
    public interface IControlBatchRun
    {
        bool Start(BatchRun batchRun);
        bool Pause(BatchRun batchRun);
    }
}