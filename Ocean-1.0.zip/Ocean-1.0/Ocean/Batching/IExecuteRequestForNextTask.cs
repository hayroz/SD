using Ocean.Batching.Entities;

namespace Ocean.Batching
{
    public interface IExecuteRequestForNextTask
    {
        void Execute(BatchRun run);
    }
}