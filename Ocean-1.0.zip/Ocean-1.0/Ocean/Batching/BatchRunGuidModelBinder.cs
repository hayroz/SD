using System;
using System.Linq;
using System.Web.Mvc;
using Ocean.Batching.Entities;
using Ocean.Website.Binders;
using NHibernate.Linq;
using Ninject;

namespace Ocean.Batching
{
    public class BatchRunGuidModelBinder : OceanDefaultModelBinder
    {
        public BatchRunGuidModelBinder(IKernel kernel)
            : base(kernel)
        {
        }

        public override object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
        {
            var id = Convert.ToString(controllerContext.RouteData.Values["id"]);
            Guid guid;
            if (Guid.TryParse(id, out guid))
            {
                return Session.Query<BatchRun>().FirstOrDefault(x => x.Guid == guid);
            }
            return null;
        }
    }
}