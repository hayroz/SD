namespace Ocean.Batching.Entities
{
    public enum JobExecutionStatus
    {
        Pending,
        Executing,
        Succeeded,
        Failed
    }
}