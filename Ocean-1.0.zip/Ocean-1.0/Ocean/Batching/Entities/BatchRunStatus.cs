namespace Ocean.Batching.Entities
{
    public enum BatchRunStatus
    {
        Pending,
        Executing,
        Paused,
        Complete
    }
}