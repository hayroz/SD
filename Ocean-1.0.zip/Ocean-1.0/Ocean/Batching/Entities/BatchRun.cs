using System.Collections.Generic;
using Ocean.Entities;

namespace Ocean.Batching.Entities
{
    public class BatchRun : SiteEntity
    {
        public virtual Batch Batch { get; set; }
        public virtual BatchRunStatus Status { get; set; }
        public virtual IList<BatchRunResult> BatchRunResults { get; set; }
    }
}