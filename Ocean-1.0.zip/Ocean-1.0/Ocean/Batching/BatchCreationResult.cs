using Ocean.Batching.Entities;

namespace Ocean.Batching
{
    public class BatchCreationResult
    {
        public BatchCreationResult(Batch batch, BatchRun initialBatchRun)
        {
            Batch = batch;
            InitialBatchRun = initialBatchRun;
        }

        public Batch Batch { get; private set; }
        public BatchRun InitialBatchRun { get; private set; }
    }
}