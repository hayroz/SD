﻿using Ocean.Batching.Entities;

namespace Ocean.Batching.CoreJobs
{
    public class RebuildUniversalSearchIndex : BatchJob
    {
        public override string Name
        {
            get { return "Rebuild Universal Index"; }
        }
    }
}