﻿using Ocean.Batching.Entities;
using Ocean.Events;

namespace Ocean.Batching.Events
{
    public interface IOnBatchRunStart : IEvent<BatchRunStartArgs>
    {
         
    }

    public class BatchRunStartArgs
    {
        public BatchRun BatchRun { get; set; }
    }
}