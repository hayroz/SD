﻿using Ocean.Batching.Entities;
using Ocean.Events;

namespace Ocean.Batching.Events
{
    public interface IOnBatchRunPause : IEvent<BatchRunPauseArgs>
    {
         
    }

    public class BatchRunPauseArgs
    {
        public BatchRun BatchRun { get; set; }
    }
}