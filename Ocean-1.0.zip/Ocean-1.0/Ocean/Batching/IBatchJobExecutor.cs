﻿using System.Threading.Tasks;
using Ocean.Batching.Entities;

namespace Ocean.Batching
{
    public interface IBatchJobExecutor
    {
        Task<BatchJobExecutionResult> Execute(BatchJob batchJob);
        bool UseAsync { get; }
    }
}