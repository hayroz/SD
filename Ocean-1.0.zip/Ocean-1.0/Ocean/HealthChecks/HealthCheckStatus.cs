﻿namespace Ocean.HealthChecks
{
    public enum HealthCheckStatus
    {
        Success,
        Failure,
        Warning,
        NotApplicable
    }
}