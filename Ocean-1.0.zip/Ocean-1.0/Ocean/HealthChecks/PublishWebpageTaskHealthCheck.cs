using System.Collections.Generic;
using System.Linq;
using Ocean.Entities.Multisite;
using Ocean.Helpers;
using Ocean.Tasks;
using NHibernate;

namespace Ocean.HealthChecks
{
    public class PublishWebpageTaskHealthCheck : HealthCheck
    {
        private readonly ITaskSettingManager _taskSettingManager;

        public PublishWebpageTaskHealthCheck(ITaskSettingManager taskSettingManager)
        {
            _taskSettingManager = taskSettingManager;
        }

        public override string DisplayName
        {
            get { return "Page Publisher task setup"; }
        }

        public override HealthCheckResult PerformCheck()
        {
            var any = _taskSettingManager.GetInfo().Any(x => x.Type == typeof(PublishScheduledWebpagesTask) && x.Enabled);

            return !any
                ? new HealthCheckResult
                {
                    Messages = new List<string>
                    {
                        "Publisher task is not set up."
                    }
                }
                : HealthCheckResult.Success;
        }
    }
}