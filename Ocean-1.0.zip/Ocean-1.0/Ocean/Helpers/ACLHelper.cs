﻿using System.Web.Mvc;
using Ocean.ACL;
using Ocean.Website;

namespace Ocean.Helpers
{
    public static class ACLHelper
    {
        public static bool CanAccess<T>(this HtmlHelper html, string operation, string type = null) where T : ACLRule, new()
        {
            return CurrentRequestData.CurrentUser != null &&
                   new T().CanAccess(CurrentRequestData.CurrentUser, operation, type);
        }
    }
}