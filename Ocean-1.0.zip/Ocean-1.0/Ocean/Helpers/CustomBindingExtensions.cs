using System.Web.Mvc;
using Ocean.Entities;
using Ocean.Services;
using Ocean.Website;

namespace Ocean.Helpers
{
    public static class CustomBindingExtensions
    {
        public static void ApplyCustomBinding<T>(this T entity, ControllerContext context) where T : SystemEntity
        {
            OceanApplication.Get<ICustomBindingService>().ApplyCustomBinding(entity, context);
        }
    }
}