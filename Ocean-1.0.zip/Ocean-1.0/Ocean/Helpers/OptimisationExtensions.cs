using System.Linq;
using System.Web.Mvc;
using System.Web.WebPages;
using Ocean.Services;
using Ocean.Website;
using Ocean.Website.Optimization;

namespace Ocean.Helpers
{
    public static class OptimisationExtensions
    {
        public static void IncludeScript(this HtmlHelper helper, string url)
        {
            var webPage = helper.ViewDataContainer as WebPageBase;
            var virtualPath = webPage == null ? string.Empty : webPage.VirtualPath;
            OceanApplication.Get<IResourceBundler>().AddScript(virtualPath, url);
        }

        public static void RenderScripts(this HtmlHelper helper)
        {
            OceanApplication.Get<IResourceBundler>().GetScripts(helper.ViewContext);
        }

        public static void IncludeCss(this HtmlHelper helper, string url)
        {
            var webPage = helper.ViewDataContainer as WebPageBase;
            var virtualPath = webPage == null ? string.Empty : webPage.VirtualPath;
            OceanApplication.Get<IResourceBundler>().AddCss(virtualPath, url);
        }

        public static void RenderCss(this HtmlHelper helper)
        {
            OceanApplication.Get<IResourceBundler>().GetCss(helper.ViewContext);
        }

        public static void AddAppUIScripts(this HtmlHelper html)
        {
            foreach (var script in OceanApplication.GetAll<IAppScriptList>().SelectMany(appScriptList => appScriptList.UIScripts))
            {
                html.IncludeScript(script);
            }
        }

        public static void AddAppAdminScripts(this HtmlHelper html)
        {
            foreach (var script in OceanApplication.GetAll<IAppScriptList>().SelectMany(appScriptList => appScriptList.AdminScripts))
            {
                html.IncludeScript(script);
            }
        }

        public static void AddAppUIStylesheets(this HtmlHelper html)
        {
            foreach (var script in OceanApplication.GetAll<IAppStylesheetList>().SelectMany(appScriptList => appScriptList.UIStylesheets))
            {
                html.IncludeCss(script);
            }
        }

        public static void AddAppAdminStylesheets(this HtmlHelper html)
        {
            foreach (var script in OceanApplication.GetAll<IAppStylesheetList>().SelectMany(appScriptList => appScriptList.AdminStylesheets))
            {
                html.IncludeCss(script);
            }
        }
    }
}