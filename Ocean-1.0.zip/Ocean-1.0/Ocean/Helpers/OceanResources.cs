using Ocean.Services.Resources;
using Ocean.Website;

namespace Ocean.Helpers
{
    public static class OceanResources
    {
        public static string Get(string key, string defaultValue = null)
        {
            return OceanApplication.Get<IStringResourceProvider>().GetValue(key, defaultValue);
        }
    }
}