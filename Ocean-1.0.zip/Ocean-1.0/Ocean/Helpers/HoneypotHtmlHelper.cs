using System.Web.Mvc;
using Ocean.Settings;
using Ocean.Website;

namespace Ocean.Helpers
{
    public static class HoneypotHtmlHelper
    {
        public static MvcHtmlString Honeypot(this HtmlHelper html)
        {
            var siteSettings = OceanApplication.Get<SiteSettings>();

            return siteSettings.HasHoneyPot
                       ? MvcHtmlString.Create(siteSettings.GetHoneypot().ToString())
                       : MvcHtmlString.Empty;
        }
    }
}