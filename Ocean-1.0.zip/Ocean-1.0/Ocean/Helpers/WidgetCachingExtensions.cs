using System.Reflection;
using Ocean.Entities.Widget;
using Ocean.Website;

namespace Ocean.Helpers
{
    public static class WidgetCachingExtensions
    {
        public static bool IsTypeCachable(this Widget widget)
        {
            return widget.GetType().GetCustomAttribute<OutputCacheableAttribute>() != null;
        }
    }
}