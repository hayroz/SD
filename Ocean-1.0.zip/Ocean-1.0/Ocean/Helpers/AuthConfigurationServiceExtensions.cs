﻿using Ocean.Services;
using Ocean.Website;
using Owin;

namespace Ocean.Helpers
{
    public static class AuthConfigurationServiceExtensions
    {
        public static void ConfigureAuth(this IAppBuilder app)
        {
            var standardAuthConfigurationService = OceanApplication.Get<IStandardAuthConfigurationService>();
            standardAuthConfigurationService.ConfigureAuth(app);
            if (CurrentRequestData.DatabaseIsInstalled)
            {
                var authConfigurationService = OceanApplication.Get<IAuthConfigurationService>();
                authConfigurationService.ConfigureAuth(app);
            }
        }
    }
}