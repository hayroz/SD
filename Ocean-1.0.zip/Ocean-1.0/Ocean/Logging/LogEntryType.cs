﻿namespace Ocean.Logging
{
    public enum LogEntryType
    {
        Error,
        Audit
    }
}