namespace Ocean.Events
{
    /// <summary>
    /// Marker interface
    /// </summary>
    public interface ICoreEvent
    {
    }
}