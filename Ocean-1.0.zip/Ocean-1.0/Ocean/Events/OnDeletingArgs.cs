using Ocean.DbConfiguration;
using Ocean.Entities;
using NHibernate;

namespace Ocean.Events
{
    public abstract class OnDeletingArgs
    {
        public abstract SystemEntity ItemBase { get; }
        public ISession Session { get; protected set; }
    }

    public class OnDeletingArgs<T> : OnDeletingArgs where T : SystemEntity
    {
        public OnDeletingArgs(EventInfo<T> info, ISession session)
        {
            Item = info.Object;
            Session = session;
        }

        public T Item { get; private set; }

        public override SystemEntity ItemBase
        {
            get { return Item; }
        }
    }
}