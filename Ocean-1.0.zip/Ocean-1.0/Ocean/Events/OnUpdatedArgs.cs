using System;
using Ocean.DbConfiguration;
using Ocean.Entities;
using NHibernate;

namespace Ocean.Events
{
    public abstract class OnUpdatedArgs
    {
        public abstract SystemEntity ItemBase { get; }
        public ISession Session { get; protected set; }
        public abstract SystemEntity OriginalBase { get; }
    }

    public class OnUpdatedArgs<T> : OnUpdatedArgs where T : SystemEntity
    {
        public OnUpdatedArgs(UpdatedEventInfo<T> info, ISession session)
        {
            Session = session;
            Item = info.Object;
            Original = info.OriginalVersion;
        }

        public bool HasChanged(Func<T, object> comparisionFunction)
        {
            return comparisionFunction(Original) != comparisionFunction(Item);
        }


        public T Item { get; set; }
        public T Original { get; set; }

        public override SystemEntity ItemBase
        {
            get { return Item; }
        }

        public override SystemEntity OriginalBase
        {
            get { return Original; }
        }
    }
}