using Ocean.Entities.Documents.Web;

namespace Ocean.Events.Documents
{
    public class OnWebpagePublishedEventArgs
    {
        public OnWebpagePublishedEventArgs(Webpage document)
        {
            Webpage = document;
        }

        public Webpage Webpage { get; set; }
    }
}