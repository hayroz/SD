namespace Ocean.Events.Documents
{
    public interface IDocumentModifiedUser
    {
        string GetInfo();
    }
}