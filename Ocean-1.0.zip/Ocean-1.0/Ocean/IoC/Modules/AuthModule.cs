using System.Collections.Generic;
using System.Web;
using Microsoft.AspNet.Identity;
using Microsoft.Owin.Security;
using Ocean.Entities.People;
using Ocean.Services;
using Ninject;
using Ninject.Modules;
using Ninject.Web.Common;

namespace Ocean.IoC.Modules
{
    public class AuthModule : NinjectModule
    {
        public override void Load()
        {
            Kernel.Bind<IAuthenticationManager>().ToMethod(context => context.Kernel.Get<HttpContextBase>().GetOwinContext().Authentication);
            Kernel.Bind<IEnumerable<IHashAlgorithm>>()
                .ToMethod(context => context.Kernel.GetAll<IHashAlgorithm>())
                .InRequestScope();
            Kernel.Bind<IEnumerable<IExternalUserSource>>()
                .ToMethod(context => context.Kernel.GetAll<IExternalUserSource>())
                .InRequestScope();
            Kernel.Bind<IUserStore<User, int>>().To<UserStore>().InRequestScope();
            Kernel.Bind<UserManager<User, int>>().ToMethod(context =>
            {
                var userManager = new UserManager<User, int>(context.Kernel.Get<IUserStore<User, int>>());
                userManager.UserValidator = new UserValidator<User, int>(userManager)
                {
                    AllowOnlyAlphanumericUserNames = false,
                };
                return userManager;
            }).InRequestScope();

        }
    }
}