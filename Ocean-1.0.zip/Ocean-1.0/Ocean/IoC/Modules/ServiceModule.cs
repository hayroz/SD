using System.Linq;
using System.Web.Mvc;
using Ocean.Helpers;
using Ocean.Settings;
using Ninject.Extensions.Conventions;
using Ninject.Modules;
using Ninject.Web.Common;

namespace Ocean.IoC.Modules
{
    //Wires up IOC automatically

    public class ServiceModule : NinjectModule
    {
        public override void Load()
        {
            Kernel.Bind(syntax => syntax.From(TypeHelper.GetAllOceanAssemblies()).SelectAllClasses()
                .Where(
                    t =>
                        !typeof(SiteSettingsBase).IsAssignableFrom(t) &&
                        !typeof(SystemSettingsBase).IsAssignableFrom(t) &&
                        !typeof(IController).IsAssignableFrom(t) && !Kernel.GetBindings(t).Any())
                .BindWith<NinjectServiceToInterfaceBinder>()
                .Configure(onSyntax => onSyntax.InRequestScope()));


        }
    }
}