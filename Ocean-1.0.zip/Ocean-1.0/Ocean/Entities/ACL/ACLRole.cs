﻿using Ocean.Entities.People;

namespace Ocean.Entities.ACL
{
    public class ACLRole : SiteEntity
    {
        public virtual UserRole UserRole { get; set; }

        public virtual string Name { get; set; }
    }
}