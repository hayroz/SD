namespace Ocean.Entities.Assets
{
    public enum ActivityType
    {
        Add,
        Update,
        Delete
    }
}