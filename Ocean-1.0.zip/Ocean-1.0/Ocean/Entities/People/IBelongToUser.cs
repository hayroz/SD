﻿namespace Ocean.Entities.People
{
    public interface IBelongToUser
    {
        User User { get; set; }
        
    }
}