﻿using System.Collections.Generic;
using Ocean.Services;

namespace Ocean.Entities.Messaging
{
    public interface IMessageTemplate<T>
    {
        List<string> GetTokens(IMessageTemplateParser messageTemplateParser);
    }
}