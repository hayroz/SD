﻿using System.ComponentModel.DataAnnotations;
using Ocean.DbConfiguration.Configuration;

namespace Ocean.Entities.Documents.Media
{
    public class ResizedImage : SiteEntity
    {
        public virtual MediaFile MediaFile { get; set; }
        public virtual Crop Crop { get; set; }
        [StringLength(450), IsDBLength]
        public virtual string Url { get; set; }
    }
}