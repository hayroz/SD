﻿namespace Ocean.Entities.Documents.Metadata
{
    public interface IGetDocumentMetadata
    {
        DocumentMetadata Metadata { get; }
    }
}