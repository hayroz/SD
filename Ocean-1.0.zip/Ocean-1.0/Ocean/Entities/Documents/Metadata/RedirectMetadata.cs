﻿using Ocean.Entities.Documents.Web;

namespace Ocean.Entities.Documents.Metadata
{
    public class RedirectMetadata : DocumentMetadataMap<Redirect>
    {
        public override string IconClass { get { return "glyphicon glyphicon-forward"; } }
        public override int DisplayOrder { get { return 6; } }
        public override string EditPartialView { get { return "RedirectEdit"; } }
        public override bool HasBodyContent { get { return false; }}
    }
}