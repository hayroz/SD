﻿using Ocean.Entities.Documents.Web;

namespace Ocean.Entities.Documents.Metadata
{
    public class DefaultDocumentMetadata<T> : DocumentMetadataMap<T> where T : Webpage, new()
    {

    }
}