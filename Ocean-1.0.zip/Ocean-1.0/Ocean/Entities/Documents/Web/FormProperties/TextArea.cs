namespace Ocean.Entities.Documents.Web.FormProperties
{
    public class TextArea : FormProperty
    {
    }
}