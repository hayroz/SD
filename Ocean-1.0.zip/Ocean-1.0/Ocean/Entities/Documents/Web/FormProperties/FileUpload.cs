namespace Ocean.Entities.Documents.Web.FormProperties
{
    public class FileUpload : FormProperty
    {
    }
}