using System;

namespace Ocean.Entities.Documents.Web
{
    /// <summary>
    /// A restricted webpage type that can only exist once in a site
    /// </summary>
    public interface IUniquePage
    {
    }
}