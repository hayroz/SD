namespace Ocean.Entities.Documents.Web
{
    public enum RoleStatus
    {
        Allowed,
        Disallowed,
        Any
    }
}