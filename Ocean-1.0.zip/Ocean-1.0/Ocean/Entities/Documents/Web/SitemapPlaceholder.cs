namespace Ocean.Entities.Documents.Web
{
    public class SitemapPlaceholder : Webpage
    {

    }
}