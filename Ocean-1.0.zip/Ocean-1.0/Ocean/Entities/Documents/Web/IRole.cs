using Ocean.Entities.People;

namespace Ocean.Entities.Documents.Web
{
    public interface IRole
    {
        Webpage Webpage { get; set; }
        UserRole UserRole { get; set; }
        bool? IsRecursive { get; set; }
    }
}