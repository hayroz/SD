using System;
using System.Collections.Generic;
using System.Linq;
using Ocean.Helpers;
using Ocean.Indexing.Management;
using Ocean.Tasks;
using Ocean.Website;

namespace Ocean.Indexing
{
    public static class IndexingHelper
    {
        public static bool AnyIndexes(object obj, LuceneOperation operation)
        {
            if (obj == null)
                return false;
            return
                IndexDefinitionTypes.Any(
                    definition => definition.GetUpdateTypes(operation).Any(type => type.IsAssignableFrom(obj.GetType())));
        }

        public static List<IndexDefinition> IndexDefinitionTypes
        {
            get
            {
                return
                    TypeHelper.GetAllConcreteTypesAssignableFrom(typeof(IndexDefinition<>))
                        .Select(type => OceanApplication.Get(type) as IndexDefinition)
                        .ToList();
            }
        }

        public static IndexDefinition Get<T>() where T :IndexDefinition
        {
            return IndexDefinitionTypes.OfType<T>().FirstOrDefault();
        }
    }
}