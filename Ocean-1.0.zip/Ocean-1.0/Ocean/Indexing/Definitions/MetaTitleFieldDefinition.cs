using System.Collections.Generic;
using Ocean.Entities.Documents.Web;
using Ocean.Entities.Indexes;
using Ocean.Indexing.Management;

namespace Ocean.Indexing.Definitions
{
    public class MetaTitleFieldDefinition : StringFieldDefinition<AdminWebpageIndexDefinition, Webpage>
    {
        public MetaTitleFieldDefinition(ILuceneSettingsService luceneSettingsService)
            : base(luceneSettingsService, "metatitle")
        {
        }

        protected override IEnumerable<string> GetValues(Webpage obj)
        {
            if (obj.MetaTitle != null) yield return obj.MetaTitle;
        }
    }
}