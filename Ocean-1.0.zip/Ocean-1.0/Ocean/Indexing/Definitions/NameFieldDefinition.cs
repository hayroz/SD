using System.Collections.Generic;
using Ocean.Entities.Documents.Web;
using Ocean.Entities.Indexes;
using Ocean.Indexing.Management;
using Ocean.Website;

namespace Ocean.Indexing.Definitions
{
    public class NameFieldDefinition : StringFieldDefinition<AdminWebpageIndexDefinition, Webpage>
    {
        public NameFieldDefinition(ILuceneSettingsService luceneSettingsService)
            : base(luceneSettingsService, "name")
        {
        }

        protected override IEnumerable<string> GetValues(Webpage obj)
        {
            if (obj.Name != null) yield return obj.Name;
        }
    }
}