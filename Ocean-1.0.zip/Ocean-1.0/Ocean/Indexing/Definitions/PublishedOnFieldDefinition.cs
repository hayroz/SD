using System;
using System.Collections.Generic;
using Lucene.Net.Documents;
using Ocean.Entities.Documents.Web;
using Ocean.Entities.Indexes;
using Ocean.Indexing.Management;

namespace Ocean.Indexing.Definitions
{
    public class PublishedOnFieldDefinition : StringFieldDefinition<AdminWebpageIndexDefinition, Webpage>
    {
        public PublishedOnFieldDefinition(ILuceneSettingsService luceneSettingsService)
            : base(luceneSettingsService, "publishon", index: Field.Index.NOT_ANALYZED)
        {
        }

        protected override IEnumerable<string> GetValues(Webpage obj)
        {
            yield return DateTools.DateToString(obj.PublishOn.GetValueOrDefault(DateTime.MaxValue), DateTools.Resolution.SECOND);
        }
    }
}