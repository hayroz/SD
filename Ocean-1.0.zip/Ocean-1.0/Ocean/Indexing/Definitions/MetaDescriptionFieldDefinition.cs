using System.Collections.Generic;
using Ocean.Entities.Documents.Web;
using Ocean.Entities.Indexes;
using Ocean.Indexing.Management;

namespace Ocean.Indexing.Definitions
{
    public class MetaDescriptionFieldDefinition : StringFieldDefinition<AdminWebpageIndexDefinition, Webpage>
    {
        public MetaDescriptionFieldDefinition(ILuceneSettingsService luceneSettingsService)
            : base(luceneSettingsService, "metadescription")
        {
        }

        protected override IEnumerable<string> GetValues(Webpage obj)
        {
            if (obj.MetaDescription != null) yield return obj.MetaDescription;
        }
    }
}