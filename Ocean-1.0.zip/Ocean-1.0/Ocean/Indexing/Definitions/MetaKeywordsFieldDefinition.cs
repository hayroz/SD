using System.Collections.Generic;
using Ocean.Entities.Documents.Web;
using Ocean.Entities.Indexes;
using Ocean.Indexing.Management;

namespace Ocean.Indexing.Definitions
{
    public class MetaKeywordsFieldDefinition : StringFieldDefinition<AdminWebpageIndexDefinition, Webpage>
    {
        public MetaKeywordsFieldDefinition(ILuceneSettingsService luceneSettingsService)
            : base(luceneSettingsService, "metakeywords")
        {
        }

        protected override IEnumerable<string> GetValues(Webpage obj)
        {
            if (obj.MetaKeywords != null) yield return obj.MetaKeywords;
        }
    }
}