using Lucene.Net.Store;
using Ocean.Entities.Multisite;
using Ocean.Services.Caching;

namespace Ocean.Indexing.Management
{
    public interface IGetLuceneDirectory : IClearCache
    {
        Directory Get(Site site, string folderName, bool useRAMCache = false);
    }
}