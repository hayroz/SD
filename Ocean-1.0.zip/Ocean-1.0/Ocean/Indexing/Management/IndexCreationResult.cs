﻿namespace Ocean.Indexing.Management
{
    public enum IndexCreationResult
    {
        Success, Failure, AlreadyExists
    }
}