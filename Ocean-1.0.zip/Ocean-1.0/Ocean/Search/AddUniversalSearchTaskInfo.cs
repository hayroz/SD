using Ocean.Website;

namespace Ocean.Search
{
    [EndRequestExecutionPriority(1)]
    public class AddUniversalSearchTaskInfo : EndRequestTask<UniversalSearchIndexData>
    {
        public AddUniversalSearchTaskInfo(UniversalSearchIndexData data)
            : base(data)
        {
        }
    }
}