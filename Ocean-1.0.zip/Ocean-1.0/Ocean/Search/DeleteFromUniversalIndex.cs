using Ocean.Entities;
using Ocean.Website;

namespace Ocean.Search
{
    public class DeleteFromUniversalIndex : EndRequestTask<SystemEntity>
    {
        public DeleteFromUniversalIndex(SystemEntity entity)
            : base(entity)
        {
        }
    }
}