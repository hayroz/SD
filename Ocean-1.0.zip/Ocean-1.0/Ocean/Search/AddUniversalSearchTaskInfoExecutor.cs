using System.Collections.Generic;
using Ocean.Entities;
using Ocean.Entities.Multisite;
using Ocean.Helpers;
using Ocean.Tasks;
using Ocean.Website;
using Newtonsoft.Json;
using NHibernate;

namespace Ocean.Search
{
    public class AddUniversalSearchTaskInfoExecutor : ExecuteEndRequestBase<AddUniversalSearchTaskInfo, UniversalSearchIndexData>
    {
        private readonly IStatelessSession _session;
        private readonly Site _site;

        public AddUniversalSearchTaskInfoExecutor(IStatelessSession session, Site site)
        {
            _session = session;
            _site = site;
        }

        public override void Execute(IEnumerable<UniversalSearchIndexData> data)
        {
            _session.Transact(session =>
            {
                foreach (var indexData in data)
                {
                    session.Insert(new QueuedTask
                    {
                        Data = JsonConvert.SerializeObject(indexData),
                        Type = typeof(UniversalSearchIndexTask).FullName,
                        Status = TaskExecutionStatus.Pending,
                        Site = GetSite(indexData),
                        CreatedOn = CurrentRequestData.Now,
                        UpdatedOn = CurrentRequestData.Now
                    });
                }
            });
        }

        private Site GetSite(UniversalSearchIndexData indexData)
        {
            var item = indexData.UniversalSearchItem;
            var entity = _session.Get(item.SystemType, item.Id) as SiteEntity;
            return entity == null || entity.Site == null
                ? _session.Get<Site>(_site.Id)
                : _session.Get<Site>(entity.Site.Id);
        }
    }
}