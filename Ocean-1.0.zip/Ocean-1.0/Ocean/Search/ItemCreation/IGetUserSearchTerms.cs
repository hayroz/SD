﻿using System.Collections.Generic;
using Ocean.Entities.People;

namespace Ocean.Search.ItemCreation
{
    public interface IGetUserSearchTerms
    {
        IEnumerable<string> GetPrimary(User user);
        Dictionary<User,HashSet<string>> GetPrimary(HashSet<User> users);
        IEnumerable<string> GetSecondary(User user);
        Dictionary<User,HashSet<string>> GetSecondary(HashSet<User> users);
    }
}