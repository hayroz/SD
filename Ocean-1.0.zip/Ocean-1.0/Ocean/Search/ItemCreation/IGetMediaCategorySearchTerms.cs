﻿using System.Collections.Generic;
using Ocean.Entities.Documents.Media;

namespace Ocean.Search.ItemCreation
{
    public interface IGetMediaCategorySearchTerms
    {
        IEnumerable<string> GetPrimary(MediaCategory mediaCategory);
        Dictionary<MediaCategory, HashSet<string>> GetPrimary(HashSet<MediaCategory> mediaCategories);
        IEnumerable<string> GetSecondary(MediaCategory mediaCategory);
        Dictionary<MediaCategory, HashSet<string>> GetSecondary(HashSet<MediaCategory> mediaCategories);
    }
}