namespace Ocean.Search
{
    public enum UniversalSearchIndexAction
    {
        Insert,
        Update,
        Delete
    }
}