using Ocean.Entities;
using Ocean.Website;

namespace Ocean.Search
{
    public class UpdateUniversalIndex : EndRequestTask<SystemEntity>
    {
        public UpdateUniversalIndex(SystemEntity entity)
            : base(entity)
        {

        }
    }
}