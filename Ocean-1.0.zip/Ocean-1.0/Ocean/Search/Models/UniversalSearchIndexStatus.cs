using System;

namespace Ocean.Search.Models
{
    public class UniversalSearchIndexStatus
    {
        public bool Exists { get; set; }
        public Guid Guid { get; set; }
    }
}