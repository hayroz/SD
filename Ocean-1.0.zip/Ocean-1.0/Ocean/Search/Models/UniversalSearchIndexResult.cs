namespace Ocean.Search.Models
{
    public class UniversalSearchIndexResult
    {
        public bool Success { get; set; }
        public string Message { get; set; }
    }
}