﻿namespace Ocean.Search
{
    public interface IUniversalSearchIndexTask
    {
        UniversalSearchIndexData UniversalSearchIndexData { get; }
    }
}