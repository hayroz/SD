using Lucene.Net.Documents;
using Ocean.Search.Models;

namespace Ocean.Search
{
    public interface ISearchConverter
    {
        Document Convert(UniversalSearchItem item);
        UniversalSearchItem Convert(Document document);
    }
}