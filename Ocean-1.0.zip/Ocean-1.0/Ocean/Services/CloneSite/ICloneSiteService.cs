using System.Collections.Generic;
using Ocean.Entities.Multisite;
using Ocean.Models;

namespace Ocean.Services.CloneSite
{
    public interface ICloneSiteService
    {
        void CloneData(Site site, List<SiteCopyOption> options);
    }
}