using Ocean.Entities.Documents.Web;

namespace Ocean.Services.CloneSite
{
    public interface ICloneWebpageSiteParts
    {
        void Clone(Webpage @from, Webpage to, SiteCloneContext siteCloneContext);
    }
}