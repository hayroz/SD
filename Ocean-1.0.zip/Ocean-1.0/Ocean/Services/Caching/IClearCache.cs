namespace Ocean.Services.Caching
{
    public interface IClearCache
    {
        void ClearCache();
    }
}