using Ocean.Website;

namespace Ocean.Services
{
    public class ApplicationRestart : EndRequestTask<int>
    {
        public ApplicationRestart()
            : base(0)
        {
        }
    }
}