using System;

namespace Ocean.DbConfiguration.Configuration
{
    [AttributeUsage(AttributeTargets.Property)]
    public class IsDBLengthAttribute : Attribute
    {
    }
}