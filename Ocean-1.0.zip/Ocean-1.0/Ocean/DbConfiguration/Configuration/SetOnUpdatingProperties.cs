﻿using System;
using Ocean.Entities;
using Ocean.Events;
using Ocean.Website;

namespace Ocean.DbConfiguration.Configuration
{
    public class SetOnUpdatingProperties : IOnUpdating<SystemEntity>
    {
        public void Execute(OnUpdatingArgs<SystemEntity> args)
        {
            DateTime now = CurrentRequestData.Now;
            SystemEntity systemEntity = args.Item;
            systemEntity.UpdatedOn = now;
        }
    }
}