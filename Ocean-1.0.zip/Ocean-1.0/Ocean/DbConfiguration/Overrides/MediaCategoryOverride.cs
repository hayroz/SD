using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;
using Ocean.Entities.Documents.Media;

namespace Ocean.DbConfiguration.Overrides
{
    public class MediaCategoryOverride : IAutoMappingOverride<MediaCategory>
    {
        public void Override(AutoMapping<MediaCategory> mapping)
        {
            mapping.HasMany(x => x.Files).KeyColumn("MediaCategoryId").Cascade.Delete();
        }
    }
}