using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;
using Ocean.Entities.Documents.Layout;

namespace Ocean.DbConfiguration.Overrides
{
    public class LayoutOverride : IAutoMappingOverride<Layout>
    {
        public void Override(AutoMapping<Layout> mapping)
        {
            mapping.HasMany(x => x.LayoutAreas).KeyColumn("LayoutId").Cascade.All().Cache.ReadWrite();
            mapping.HasMany(layout => layout.PageTemplates).KeyColumn("LayoutId").Cascade.None();
        }
    }
}