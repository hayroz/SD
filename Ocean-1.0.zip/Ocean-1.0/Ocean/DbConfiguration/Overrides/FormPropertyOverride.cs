﻿using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;
using Ocean.Entities.Documents.Web.FormProperties;

namespace Ocean.DbConfiguration.Overrides
{
    public class FormPropertyOverride : IAutoMappingOverride<FormProperty>
    {
        public void Override(AutoMapping<FormProperty> mapping)
        {
            mapping.DiscriminateSubClassesOnColumn("PropertyType");
        }
    }
}