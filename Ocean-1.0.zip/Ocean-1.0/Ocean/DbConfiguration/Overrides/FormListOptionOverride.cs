using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;
using Ocean.Entities.Documents.Web.FormProperties;

namespace Ocean.DbConfiguration.Overrides
{
    public class FormListOptionOverride : IAutoMappingOverride<FormListOption>
    {
        public void Override(AutoMapping<FormListOption> mapping)
        {
            mapping.References(option => option.FormProperty).Column("FormPropertyId");
        }
    }
}