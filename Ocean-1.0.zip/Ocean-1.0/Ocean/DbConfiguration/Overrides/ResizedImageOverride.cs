using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;
using Ocean.Entities.Documents.Media;

namespace Ocean.DbConfiguration.Overrides
{
    public class ResizedImageOverride : IAutoMappingOverride<ResizedImage>
    {
        public void Override(AutoMapping<ResizedImage> mapping)
        {
            mapping.Map(file => file.Url).Length(1000);
        }
    }
}