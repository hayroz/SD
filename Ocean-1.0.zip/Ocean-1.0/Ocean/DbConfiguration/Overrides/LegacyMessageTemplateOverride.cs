﻿using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;
using Ocean.Entities.Messaging;

namespace Ocean.DbConfiguration.Overrides
{
    public class LegacyMessageTemplateOverride : IAutoMappingOverride<LegacyMessageTemplate>
    {
        public void Override(AutoMapping<LegacyMessageTemplate> mapping)
        {
            mapping.Table("MessageTemplate");
        }
    }
}