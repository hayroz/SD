﻿using FluentNHibernate.Automapping;
using FluentNHibernate.Automapping.Alterations;
using Ocean.Entities.Documents.Web.FormProperties;

namespace Ocean.DbConfiguration.Overrides
{
    public class FormPropertyWithOptionsOverride : IAutoMappingOverride<FormPropertyWithOptions>
    {
        public void Override(AutoMapping<FormPropertyWithOptions> mapping)
        {
            mapping.HasMany(options => options.Options).KeyColumn("FormPropertyId");
        }
    }
}