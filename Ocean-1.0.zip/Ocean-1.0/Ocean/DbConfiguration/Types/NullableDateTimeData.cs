﻿using System;
using Ocean.Website;

namespace Ocean.DbConfiguration.Types
{
    [Serializable]
    public class NullableDateTimeData : NullableDateTimeDataBase
    {
        protected override TimeZoneInfo TimeZone
        {
            get { return CurrentRequestData.TimeZoneInfo; }
        }
    }
}