﻿using System;

namespace Ocean.DbConfiguration.Types
{
    [Serializable]
    public class LocalNullableDateTimeData : NullableDateTimeDataBase
    {
        protected override TimeZoneInfo TimeZone
        {
            get { return TimeZoneInfo.Local; }
        }
    }
}