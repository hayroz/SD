using Ocean.Settings;

namespace Ocean.DbConfiguration
{
    public class CreateSqlServerAzureDatabase :CreateSqlServerDatabase, ICreateDatabase<SqlServerAzureProvider>
    {
        protected override IDatabaseProvider GetProvider(string connectionString)
        {
            return new SqlServerAzureProvider(new DatabaseSettings
            {
                ConnectionString = connectionString
            });
        }
    }
}