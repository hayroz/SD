using FluentNHibernate.Cfg.Db;

namespace Ocean.DbConfiguration
{
    public interface IDatabaseProvider
    {
        string Type { get; }
        IPersistenceConfigurer GetPersistenceConfigurer();
        void AddProviderSpecificConfiguration(NHibernate.Cfg.Configuration config);
    }
}