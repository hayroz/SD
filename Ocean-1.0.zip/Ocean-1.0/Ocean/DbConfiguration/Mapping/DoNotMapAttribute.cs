using System;

namespace Ocean.DbConfiguration.Mapping
{
    public class DoNotMapAttribute : Attribute
    {
    }
}