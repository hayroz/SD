using System;

namespace Ocean.DbConfiguration
{
    [AttributeUsage(AttributeTargets.Property)]
    public class NotNullableAttribute : Attribute
    {
    }
}