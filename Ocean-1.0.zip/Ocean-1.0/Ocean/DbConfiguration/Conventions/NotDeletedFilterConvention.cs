using FluentNHibernate.Conventions;
using FluentNHibernate.Conventions.Instances;
using Ocean.DbConfiguration.Filters;

namespace Ocean.DbConfiguration.Conventions
{
    public class NotDeletedFilterConvention : IClassConvention
    {
        public void Apply(IClassInstance instance)
        {
            instance.ApplyFilter<NotDeletedFilter>();
        }
    }
}