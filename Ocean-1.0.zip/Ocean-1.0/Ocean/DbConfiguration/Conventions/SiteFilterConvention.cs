using FluentNHibernate.Conventions;
using FluentNHibernate.Conventions.Instances;
using Ocean.DbConfiguration.Filters;
using Ocean.Entities;

namespace Ocean.DbConfiguration.Conventions
{
    public class SiteFilterConvention : IClassConvention
    {
        public void Apply(IClassInstance instance)
        {
            if (instance.EntityType.IsSubclassOf(typeof (SiteEntity)))
            {
                instance.ApplyFilter<SiteFilter>();
            }
        }
    }
}