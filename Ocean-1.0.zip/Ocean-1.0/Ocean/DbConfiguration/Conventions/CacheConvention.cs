using FluentNHibernate.Conventions;
using FluentNHibernate.Conventions.Instances;
using Ocean.Entities;
using Ocean.Entities.Documents;

namespace Ocean.DbConfiguration.Conventions
{
    public class CacheConvention : IClassConvention
    {
        public void Apply(IClassInstance instance)
        {
            instance.Cache.ReadWrite();
        }
    }
}