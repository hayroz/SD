using System;

namespace Ocean.DbConfiguration
{
    public class NoConnectionStringBuilderAttribute : Attribute
    {
    }
}