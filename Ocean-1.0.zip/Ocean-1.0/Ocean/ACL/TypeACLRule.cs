﻿using System;
using System.Collections.Generic;
using System.Linq;
using Ocean.Apps;
using Ocean.Entities;
using Ocean.Entities.Documents.Web;
using Ocean.Entities.Widget;
using Ocean.Helpers;
using Ocean.Models;

namespace Ocean.ACL
{
    public class TypeACLRule : ACLRule
    {
        private List<ACLGroup> _rules;
        public const string Add = "Add";
        public const string Edit = "Edit";
        public const string Delete = "Delete";

        public override string DisplayName
        {
            get { return "Webpage"; }
        }

        public IEnumerable<ACLGroup> WebpageRules
        {
            get { return GetRules().Where(group => group.Type.IsSubclassOf(typeof(Webpage))); }
        }

        public IEnumerable<ACLGroup> WidgetRules
        {
            get { return GetRules().Where(group => group.Type.IsSubclassOf(typeof(Widget))); }
        }

        public override List<ACLGroup> GetRules()
        {
            return _rules = _rules ?? GetRuleTypes()
                                                .Select(
                                                    type => new ACLGroup
                                                    {
                                                        Name = type.Name.BreakUpString(),
                                                        Type = type,
                                                        AppName = GetAppName(type),
                                                        Operations =
                                                            Operations.Select(s =>
                                                                              new ACLOperation
                                                                              {
                                                                                  Name = s,
                                                                                  Key = GetKey(s, type.FullName),
                                                                              }).ToList()
                                                    }).ToList();
        }

        private string GetAppName(Type type)
        {
            if (OceanApp.AppWebpages.ContainsKey(type))
                return OceanApp.AppWebpages[type];
            if (OceanApp.AppWidgets.ContainsKey(type))
                return OceanApp.AppWidgets[type];
            return "System";
        }

        private static HashSet<Type> GetRuleTypes()
        {
            return TypeHelper.GetAllConcreteMappedClassesAssignableFrom<SystemEntity>().FindAll(type => type.IsSubclassOf(typeof(Widget)) || type.IsSubclassOf(typeof(Webpage)));
        }

        protected override List<string> GetOperations()
        {
            return new List<string>
                       {
                           Add,
                           Edit,
                           Delete,
                       };
        }
    }
}