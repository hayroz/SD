namespace Ocean.Messages
{
    public class ExportDocumentsEmailTemplate : MessageTemplate
    {
    }
}