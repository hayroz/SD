namespace Ocean.Messages
{
    public interface IGetDefaultMessageTemplate
    {
        MessageTemplate Get();
    }
}