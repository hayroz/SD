using System.Web.Mvc;

namespace Ocean.Models
{
    public class SiteTree<T> : SiteTreeNode<T>
    {
    }
}