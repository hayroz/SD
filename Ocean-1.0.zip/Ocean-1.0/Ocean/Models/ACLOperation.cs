﻿namespace Ocean.Models
{
    public class ACLOperation
    {
        public string Name { get; set; }

        public string Key { get; set; }
    }
}