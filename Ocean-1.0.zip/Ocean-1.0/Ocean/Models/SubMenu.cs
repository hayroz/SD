﻿using System.Collections.Generic;

namespace Ocean.Models
{
    public class SubMenu :List<ChildMenuItem>
    {
        
    }
}