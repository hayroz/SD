namespace Ocean.Models
{
    public class AutoCompleteResult
    {
        public int id { get; set; }
        public string label { get; set; }
        public string value { get; set; }
    }
}