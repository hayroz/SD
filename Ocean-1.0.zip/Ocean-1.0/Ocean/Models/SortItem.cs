namespace Ocean.Models
{
    public class SortItem
    {
        public string Name { get; set; }
        public int Id { get; set; }
        public int Order { get; set; }
    }
}