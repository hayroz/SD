namespace Ocean.Models
{
    public class ExportDocumentsResult
    {
        public bool Success { get; set; }
        public string Message { get; set; }
    }
}