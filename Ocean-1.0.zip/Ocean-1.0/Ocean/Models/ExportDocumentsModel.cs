using System.ComponentModel.DataAnnotations;
using Ocean.Helpers.Validation;

namespace Ocean.Models
{
    public class ExportDocumentsModel
    {
        [Required, EmailValidator]
        public string Email { get; set; }
    }
}